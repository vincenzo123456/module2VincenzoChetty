// my variables

let names = "Muzi Zwane";
let institution = "UJ";
let github = "MuziZwane";

// display results
console.log("my name is " + names + " " + "a student from " + institution + ". my Github username is " + github);
